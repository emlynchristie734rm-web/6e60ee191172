// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("outdated deps\n", stdout);
  return lionss_run_workload("outdated-deps");
}
