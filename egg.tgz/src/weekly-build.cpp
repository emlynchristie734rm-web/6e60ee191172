// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("weekly build\n", stdout);
  return lionss_run_workload("weekly-build");
}
