// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("serialization tests\n", stdout);
  return lionss_run_workload("serialization-tests");
}
